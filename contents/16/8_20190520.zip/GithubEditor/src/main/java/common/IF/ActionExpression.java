package common.IF;

public interface ActionExpression<T> {
	void run(T node);
}