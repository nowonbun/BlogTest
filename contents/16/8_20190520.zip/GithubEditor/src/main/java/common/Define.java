package common;

public class Define {
	public static final String USER_SESSION_NAME = "USER";
	public static final String COOKIE_KEY = "NowonbunBlogEditor";
}