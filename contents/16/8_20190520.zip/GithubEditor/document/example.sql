insert into category(code,name,uniqcode,p_category_code,isactive,seq) values('0100','Dev','dev',null,1,1);
insert into category(code,name,uniqcode,p_category_code,isactive,seq) values('0200','Study','study',null,1,2);
insert into category(code,name,uniqcode,p_category_code,isactive,seq) values('0101','Java','java','0100',1,1);
insert into category(code,name,uniqcode,p_category_code,isactive,seq) values('0102','C#','Csharp','0100',1,2);
insert into category(code,name,uniqcode,p_category_code,isactive,seq) values('0201','php','php','0200',1,1);
insert into category(code,name,uniqcode,p_category_code,isactive,seq) values('0202','python','python','0200',1,2);
insert into category(code,name,uniqcode,p_category_code,isactive,seq) values('9900','Other','other',null,1,1);